
#pragma once

#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
EXPORT_ void InitializeSnobotCallbacks();
EXPORT_ void ResetSnobotCallbacks();
} // namespace SnobotSim
