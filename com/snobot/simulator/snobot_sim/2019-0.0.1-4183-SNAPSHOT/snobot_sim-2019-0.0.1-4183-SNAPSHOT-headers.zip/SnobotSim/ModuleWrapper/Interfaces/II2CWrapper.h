/*
 * II2CWrapper.h
 *
 *  Created on: Jun 22, 2017
 *      Author: preiniger
 */

#pragma once

#include "SnobotSim/ExportHelper.h"

class II2CWrapper
{
public:
    virtual ~II2CWrapper()
    {
    }
};
