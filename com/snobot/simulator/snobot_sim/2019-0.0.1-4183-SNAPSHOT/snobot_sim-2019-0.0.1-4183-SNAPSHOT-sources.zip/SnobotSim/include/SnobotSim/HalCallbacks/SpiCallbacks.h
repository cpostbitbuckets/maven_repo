/*
 * SpiCallbacks.h
 *
 *  Created on: Sep 11, 2017
 *      Author: preiniger
 */

#pragma once

#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
EXPORT_ void InitializeSpiCallbacks();
EXPORT_ void ResetSpiCallbacks();
} // namespace SnobotSim
