

#pragma once
namespace StackTraceHelper
{
void PrintStackTracker();
} // namespace StackTraceHelper
