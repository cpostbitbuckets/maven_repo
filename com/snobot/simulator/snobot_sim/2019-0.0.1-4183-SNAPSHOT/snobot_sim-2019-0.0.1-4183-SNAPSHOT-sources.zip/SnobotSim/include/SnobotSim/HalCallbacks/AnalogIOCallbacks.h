
#pragma once

#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
EXPORT_ void InitializeAnalogIOCallbacks();
EXPORT_ void ResetAnalogIOCallbacks();
} // namespace SnobotSim
