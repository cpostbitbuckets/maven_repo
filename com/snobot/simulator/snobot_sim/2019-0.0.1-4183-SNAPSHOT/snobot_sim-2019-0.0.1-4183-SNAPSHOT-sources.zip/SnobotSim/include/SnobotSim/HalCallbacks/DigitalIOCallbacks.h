
#pragma once

#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
EXPORT_ void InitializeDigitalIOCallbacks();
EXPORT_ void ResetDigitalIOCallbacks();
} // namespace SnobotSim
