
#pragma once

#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
EXPORT_ void InitializeEncoderCallbacks();
EXPORT_ void ResetEncoderCallbacks();
} // namespace SnobotSim
