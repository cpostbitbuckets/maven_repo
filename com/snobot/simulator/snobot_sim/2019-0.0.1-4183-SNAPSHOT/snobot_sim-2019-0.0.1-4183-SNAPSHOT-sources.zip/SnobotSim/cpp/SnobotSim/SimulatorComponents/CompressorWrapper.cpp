/*
 * CompressorWrapper.cpp
 *
 *  Created on: Jun 22, 2017
 *      Author: preiniger
 */

#include "SnobotSim/SimulatorComponents/CompressorWrapper.h"

CompressorWrapper::CompressorWrapper()
{
}

CompressorWrapper::~CompressorWrapper()
{
}

bool CompressorWrapper::IsPressureSwitchFull()
{
    return true;
}
