var classwpi_1_1_logger =
[
    [ "LogFunc", "classwpi_1_1_logger.html#a070956ea34ca4a590d4c6934c670598e", null ],
    [ "Logger", "classwpi_1_1_logger.html#ad34899da9fc689653c09759b05b5f512", null ],
    [ "Logger", "classwpi_1_1_logger.html#af4eba6ece98c2de51c01226b60f4f298", null ],
    [ "Logger", "classwpi_1_1_logger.html#aa0ae0533c7300ce979a90c68fc41f403", null ],
    [ "HasLogger", "classwpi_1_1_logger.html#a9913d834826db7d47f718ca3ee2e60a7", null ],
    [ "Log", "classwpi_1_1_logger.html#ac889584b40ed5e0043b9096e8d278a2e", null ],
    [ "min_level", "classwpi_1_1_logger.html#a5d005db35f0760d2cca397a3c7aa5036", null ],
    [ "set_min_level", "classwpi_1_1_logger.html#a4b5ec5e61899fcabe0d0d630418dec7d", null ],
    [ "SetLogger", "classwpi_1_1_logger.html#ac9df65e435a14cbdce8d00b255d0ff1e", null ]
];