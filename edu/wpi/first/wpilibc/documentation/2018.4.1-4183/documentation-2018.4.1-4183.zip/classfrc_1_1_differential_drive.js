var classfrc_1_1_differential_drive =
[
    [ "DifferentialDrive", "classfrc_1_1_differential_drive.html#ab5c27ab3615a86dfb40b1843e4db5ac4", null ],
    [ "~DifferentialDrive", "classfrc_1_1_differential_drive.html#aa29cfe8b33ef9fd72e7c0eea70ce4edb", null ],
    [ "DifferentialDrive", "classfrc_1_1_differential_drive.html#a1f4313b48f19eb5d7933804c3ef34ba1", null ],
    [ "ArcadeDrive", "classfrc_1_1_differential_drive.html#aedccabfe77540785c538eb24b7f4b2a4", null ],
    [ "CurvatureDrive", "classfrc_1_1_differential_drive.html#a7f6af2233e75b79f70faaac79c929e87", null ],
    [ "GetDescription", "classfrc_1_1_differential_drive.html#ab9da8a63cdd344b0b9048401bf670c2a", null ],
    [ "InitSendable", "classfrc_1_1_differential_drive.html#a33736c0962c6f6af31cdd1b9f8c9f6d8", null ],
    [ "IsRightSideInverted", "classfrc_1_1_differential_drive.html#a82268ef5c0a229c434f2401600672906", null ],
    [ "operator=", "classfrc_1_1_differential_drive.html#adcf20b07c40750172d91f149f8ccc17c", null ],
    [ "SetQuickStopAlpha", "classfrc_1_1_differential_drive.html#a84ca647284c060a1774b7d4eae96b157", null ],
    [ "SetQuickStopThreshold", "classfrc_1_1_differential_drive.html#a1853e358d0e0af045f9820d6357e5f31", null ],
    [ "SetRightSideInverted", "classfrc_1_1_differential_drive.html#a06cfc6148b98cc4053883ccc97012862", null ],
    [ "StopMotor", "classfrc_1_1_differential_drive.html#ae5b11f3e8ed93ec77d4eb0b51f4b5e20", null ],
    [ "TankDrive", "classfrc_1_1_differential_drive.html#a1ab88dd9c8d8611764da9ffa6063f72d", null ]
];