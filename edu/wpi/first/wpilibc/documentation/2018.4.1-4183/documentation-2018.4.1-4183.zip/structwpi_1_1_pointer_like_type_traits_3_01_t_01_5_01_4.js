var structwpi_1_1_pointer_like_type_traits_3_01_t_01_5_01_4 =
[
    [ "NumLowBitsAvailable", "structwpi_1_1_pointer_like_type_traits_3_01_t_01_5_01_4.html#afc028856a14e8483e91f4997dc9993b0a06990b062427319e2225641dd1ee3d3b", null ]
];