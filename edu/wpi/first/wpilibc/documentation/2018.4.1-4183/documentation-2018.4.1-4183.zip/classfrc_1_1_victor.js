var classfrc_1_1_victor =
[
    [ "Victor", "classfrc_1_1_victor.html#a73c44c9e0a33347f91298b9764909286", null ],
    [ "Victor", "classfrc_1_1_victor.html#ac58a5fa27f4e2811c9a5293d20c3e1c0", null ],
    [ "operator=", "classfrc_1_1_victor.html#afb99f0769bdd70c73d89e9177b0f8b49", null ]
];