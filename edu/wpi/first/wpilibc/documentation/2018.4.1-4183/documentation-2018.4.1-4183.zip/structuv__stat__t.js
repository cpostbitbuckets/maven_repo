var structuv__stat__t =
[
    [ "st_atim", "structuv__stat__t.html#a90374cf48291ecde29394d1982b9eec8", null ],
    [ "st_birthtim", "structuv__stat__t.html#a324b6bb9a3dcb70259e0195379c5f9ef", null ],
    [ "st_blksize", "structuv__stat__t.html#af549bc8ae4793b83fa25b97fc5518e67", null ],
    [ "st_blocks", "structuv__stat__t.html#a7cb4ce091e3b7418f368451dd60e535e", null ],
    [ "st_ctim", "structuv__stat__t.html#a7785fcfd6909d22b07f8461219ca2133", null ],
    [ "st_dev", "structuv__stat__t.html#ac1f0764990fe34d0b21f7e3af9fef946", null ],
    [ "st_flags", "structuv__stat__t.html#a14bc9565a316b65e422dde506d4c6428", null ],
    [ "st_gen", "structuv__stat__t.html#ab5036343ef8adaabecc2362f5905b9cb", null ],
    [ "st_gid", "structuv__stat__t.html#aa6d1907b84accf5662140cb0834e479d", null ],
    [ "st_ino", "structuv__stat__t.html#a1442738c45923c0a23f7ee0c2837f584", null ],
    [ "st_mode", "structuv__stat__t.html#a198c4352c514e9eff06e7363c3562a8f", null ],
    [ "st_mtim", "structuv__stat__t.html#a89f339b980cacb16da47d7a7c04f7e8a", null ],
    [ "st_nlink", "structuv__stat__t.html#a05b9207a1a204eae78b2c7dc0d3812ab", null ],
    [ "st_rdev", "structuv__stat__t.html#af0cc8e07491b42cd8b82d797ec5af0b4", null ],
    [ "st_size", "structuv__stat__t.html#a454ac6f7cef9a00d73baf2028fe3a7cb", null ],
    [ "st_uid", "structuv__stat__t.html#ac56d6239041749e7bc4ccc472aa800b1", null ]
];