var classwpi_1_1_thread_safe_ref_counted_base =
[
    [ "ThreadSafeRefCountedBase", "classwpi_1_1_thread_safe_ref_counted_base.html#af6ecd1ac4c143d644b611a6894af5026", null ],
    [ "Release", "classwpi_1_1_thread_safe_ref_counted_base.html#a0bb2b38a209b9f87186ecf4c494af918", null ],
    [ "Retain", "classwpi_1_1_thread_safe_ref_counted_base.html#a98f046c5e0d701927850b0a3388fd86e", null ]
];