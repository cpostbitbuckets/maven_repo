var group__ntcore__rpc__cfunc =
[
    [ "NT_RpcCallback", "group__ntcore__rpc__cfunc.html#ga85793d04b8c8ba332abe2db5c4efd915", null ],
    [ "NT_CallRpc", "group__ntcore__rpc__cfunc.html#gaaf2b88d0559e728fad3f29768cf461d3", null ],
    [ "NT_CancelPollRpc", "group__ntcore__rpc__cfunc.html#gad1a48a36a7bf37cf3f00ae26bd8dc4ea", null ],
    [ "NT_CancelRpcResult", "group__ntcore__rpc__cfunc.html#ga13dac0f3caf774a54c727ddb1ad20c9f", null ],
    [ "NT_CreatePolledRpc", "group__ntcore__rpc__cfunc.html#ga878ff7a7b432fd6c0b8eee764ee4120a", null ],
    [ "NT_CreateRpc", "group__ntcore__rpc__cfunc.html#gaab91bc59f5a82124864f78d80ab99784", null ],
    [ "NT_CreateRpcCallPoller", "group__ntcore__rpc__cfunc.html#gaf8d942f44d38f62131351d570d80be6a", null ],
    [ "NT_DestroyRpcCallPoller", "group__ntcore__rpc__cfunc.html#ga25915112fcb5e7adba02b130629e6093", null ],
    [ "NT_GetRpcResult", "group__ntcore__rpc__cfunc.html#gacd97e095d6bb046d67ad8a2f1e9d5fbe", null ],
    [ "NT_GetRpcResultTimeout", "group__ntcore__rpc__cfunc.html#ga3aa1b97f51c05de47544b223552ff396", null ],
    [ "NT_PackRpcDefinition", "group__ntcore__rpc__cfunc.html#ga83136a784573ddf15f5966e44ed841b2", null ],
    [ "NT_PackRpcValues", "group__ntcore__rpc__cfunc.html#ga2fc74beb34e88d91d332c20c8fe27c1b", null ],
    [ "NT_PollRpc", "group__ntcore__rpc__cfunc.html#ga93d69a8cf511f382e37ad80cddd48b00", null ],
    [ "NT_PollRpcTimeout", "group__ntcore__rpc__cfunc.html#ga800437b55c2ebf5b448402420bd2b2c2", null ],
    [ "NT_PostRpcResponse", "group__ntcore__rpc__cfunc.html#ga2288603e819eafc06b5534e962c53ca3", null ],
    [ "NT_UnpackRpcDefinition", "group__ntcore__rpc__cfunc.html#gaf32669d9df431ba49db556212f1acea3", null ],
    [ "NT_UnpackRpcValues", "group__ntcore__rpc__cfunc.html#gac117995d857dcc94828f458c99e94f5f", null ],
    [ "NT_WaitForRpcCallQueue", "group__ntcore__rpc__cfunc.html#gad6e443f5e1fce0c35d101658e0449f0b", null ]
];