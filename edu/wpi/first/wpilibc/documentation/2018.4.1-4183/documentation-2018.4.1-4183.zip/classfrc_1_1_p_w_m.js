var classfrc_1_1_p_w_m =
[
    [ "PeriodMultiplier", "classfrc_1_1_p_w_m.html#a229fe8d5000cb865b0562daded70c270", [
      [ "kPeriodMultiplier_1X", "classfrc_1_1_p_w_m.html#a229fe8d5000cb865b0562daded70c270a04701c2461a233d866d0be00855ad3a6", null ],
      [ "kPeriodMultiplier_2X", "classfrc_1_1_p_w_m.html#a229fe8d5000cb865b0562daded70c270a69c58b2c19ccdcc9af1d7d1a9b101e22", null ],
      [ "kPeriodMultiplier_4X", "classfrc_1_1_p_w_m.html#a229fe8d5000cb865b0562daded70c270a44d8c0fe6214821e58b9595a930a4c93", null ]
    ] ],
    [ "PWM", "classfrc_1_1_p_w_m.html#a451b63e646c22cbab561a3f1ae7bd538", null ],
    [ "~PWM", "classfrc_1_1_p_w_m.html#ae42c7e3b23926966ac17323a6e9697b4", null ],
    [ "PWM", "classfrc_1_1_p_w_m.html#a4ce49cf579c0906cc88f8d706fcea34b", null ],
    [ "EnableDeadbandElimination", "classfrc_1_1_p_w_m.html#a3fbd272cb13a4f5e96f8284704fcbd3f", null ],
    [ "GetChannel", "classfrc_1_1_p_w_m.html#a2cb733b3d752e496705f00c2fb7dea00", null ],
    [ "GetPosition", "classfrc_1_1_p_w_m.html#ac78bbbffc705ee5b52f54613566804d9", null ],
    [ "GetRaw", "classfrc_1_1_p_w_m.html#a064a031fc80ef0f5a197acc97626d4d2", null ],
    [ "GetRawBounds", "classfrc_1_1_p_w_m.html#aa9756be27d3c29450b0da87981f3f921", null ],
    [ "GetSpeed", "classfrc_1_1_p_w_m.html#a4e56b8f06912670fb5a46fc29ba88796", null ],
    [ "InitSendable", "classfrc_1_1_p_w_m.html#af24a2e3193e536b40909b7f0bbe4790d", null ],
    [ "operator=", "classfrc_1_1_p_w_m.html#a248a12422c10b5b421a1870a64805e72", null ],
    [ "SetBounds", "classfrc_1_1_p_w_m.html#ad6961fb56ca5018388836707e568b94e", null ],
    [ "SetDisabled", "classfrc_1_1_p_w_m.html#a4667fefcb5a584c1c0049741a4109bc8", null ],
    [ "SetPeriodMultiplier", "classfrc_1_1_p_w_m.html#aeb7db140b4da8d87cbf3fdf1343e8c53", null ],
    [ "SetPosition", "classfrc_1_1_p_w_m.html#a2dcdc1fb2f51e5cbdf4399c10750c1b8", null ],
    [ "SetRaw", "classfrc_1_1_p_w_m.html#a01390604df9af3793d58a0e9e9fd4f01", null ],
    [ "SetRawBounds", "classfrc_1_1_p_w_m.html#a25c769d94cf902d659ceeffc4a2c52e6", null ],
    [ "SetSpeed", "classfrc_1_1_p_w_m.html#a613ec09042c118168fef4e300cb2e7bc", null ],
    [ "SetZeroLatch", "classfrc_1_1_p_w_m.html#ac6fba19d9fb79e42d37d97bd6072238e", null ]
];