var classcs_1_1_video_event =
[
    [ "GetProperty", "classcs_1_1_video_event.html#a4398e2aff4298c05fc1fc8189bc9a5d9", null ],
    [ "GetSink", "classcs_1_1_video_event.html#a866252a422f3dbd10d92da463ae4d213", null ],
    [ "GetSource", "classcs_1_1_video_event.html#a464e0f2b70e04e32f367c32b9c9be282", null ]
];