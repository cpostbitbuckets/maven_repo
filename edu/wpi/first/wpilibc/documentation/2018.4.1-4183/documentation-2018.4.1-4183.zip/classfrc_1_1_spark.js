var classfrc_1_1_spark =
[
    [ "Spark", "classfrc_1_1_spark.html#a8ba230d32f557843a520be5161b20c7e", null ],
    [ "Spark", "classfrc_1_1_spark.html#abe97cb9fe898e656530a2a478cc4f838", null ],
    [ "operator=", "classfrc_1_1_spark.html#a092bc4e0637027aa496ef7dd4eb4b0d9", null ]
];