var structwpi_1_1identity =
[
    [ "argument_type", "structwpi_1_1identity.html#a844403a752d73b893b7e05b26ccfaf75", null ],
    [ "operator()", "structwpi_1_1identity.html#a438aa8be689e9b1253ee7ba2cfc51731", null ],
    [ "operator()", "structwpi_1_1identity.html#afe0ad8a4711db43183c322ccdd841f33", null ]
];