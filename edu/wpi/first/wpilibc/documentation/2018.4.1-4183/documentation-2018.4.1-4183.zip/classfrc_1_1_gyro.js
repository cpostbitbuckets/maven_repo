var classfrc_1_1_gyro =
[
    [ "Gyro", "classfrc_1_1_gyro.html#a4636d4ca74c9319567e08b364b9a0ce8", null ],
    [ "~Gyro", "classfrc_1_1_gyro.html#a3c8e00a2f3ac4110192a28cabc094171", null ],
    [ "Gyro", "classfrc_1_1_gyro.html#ad0e093f0354fe418b057b1efd72d83a9", null ],
    [ "Calibrate", "classfrc_1_1_gyro.html#a381a388cfe4b8d30240184b51cb939e2", null ],
    [ "GetAngle", "classfrc_1_1_gyro.html#a1802eb8ee9642b60bf59dba05e9036c1", null ],
    [ "GetRate", "classfrc_1_1_gyro.html#a1567c8744fd0a71bb67901e90bb6f9fc", null ],
    [ "operator=", "classfrc_1_1_gyro.html#af929ed9d4d14773a9f0f7753e5904436", null ],
    [ "Reset", "classfrc_1_1_gyro.html#aa2f1ca35c02187828ab896b7cae20330", null ]
];