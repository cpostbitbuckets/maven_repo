var classhal_1_1_limited_handle_resource =
[
    [ "LimitedHandleResource", "classhal_1_1_limited_handle_resource.html#a01f41aff0d69c2f74c7ff9b30f76058c", null ],
    [ "LimitedHandleResource", "classhal_1_1_limited_handle_resource.html#aca8f6afc5d3e5ec2a8ffc6900bb99e93", null ],
    [ "Allocate", "classhal_1_1_limited_handle_resource.html#a9750eb560946df36d58bca9933afdc95", null ],
    [ "Free", "classhal_1_1_limited_handle_resource.html#aeb4031ac7d3a2047d8efcca6ec74b4cb", null ],
    [ "Get", "classhal_1_1_limited_handle_resource.html#af9b0557d90d9881fa17be95973cf1118", null ],
    [ "operator=", "classhal_1_1_limited_handle_resource.html#aa2445353e01906e93389600b608cd97c", null ],
    [ "ResetHandles", "classhal_1_1_limited_handle_resource.html#a56c04a0e6960278f1e44660e4153e565", null ],
    [ "LimitedHandleResourceTest", "classhal_1_1_limited_handle_resource.html#af295b356fc205e8908316565fe31fba2", null ]
];