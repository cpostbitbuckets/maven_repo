var group__ntcore__typedgetters__cfunc =
[
    [ "NT_GetEntryBoolean", "group__ntcore__typedgetters__cfunc.html#ga2b6a888a3b2b095ba18c311fe3426298", null ],
    [ "NT_GetEntryBooleanArray", "group__ntcore__typedgetters__cfunc.html#gad1bea0df8a4b5788c378f4688f841951", null ],
    [ "NT_GetEntryDouble", "group__ntcore__typedgetters__cfunc.html#ga7ffa611ac1b899c70dfbfe30e09291ff", null ],
    [ "NT_GetEntryDoubleArray", "group__ntcore__typedgetters__cfunc.html#ga62d9778f8dfe7e74064b43e42b857ecc", null ],
    [ "NT_GetEntryRaw", "group__ntcore__typedgetters__cfunc.html#ga025667abf1ebe7a77601dcf4f3fd8632", null ],
    [ "NT_GetEntryString", "group__ntcore__typedgetters__cfunc.html#gafb40235fb74b4063bbd101d8cb86ed00", null ],
    [ "NT_GetEntryStringArray", "group__ntcore__typedgetters__cfunc.html#gae8f77f58748d30870731f450ba07a7be", null ],
    [ "NT_GetValueBoolean", "group__ntcore__typedgetters__cfunc.html#gae0baa9869569002315d5197c1556649f", null ],
    [ "NT_GetValueBooleanArray", "group__ntcore__typedgetters__cfunc.html#ga202e5f30ae90cde9b0dea4e4464abcb4", null ],
    [ "NT_GetValueDouble", "group__ntcore__typedgetters__cfunc.html#gaabea79578421e6342b9c23406f680823", null ],
    [ "NT_GetValueDoubleArray", "group__ntcore__typedgetters__cfunc.html#ga66ee0b36f439f2822fd7195e7b960f7e", null ],
    [ "NT_GetValueRaw", "group__ntcore__typedgetters__cfunc.html#gae18b540cec024cfc5941013e5d45ddab", null ],
    [ "NT_GetValueString", "group__ntcore__typedgetters__cfunc.html#gab120380be861101d44e36d03849e900d", null ],
    [ "NT_GetValueStringArray", "group__ntcore__typedgetters__cfunc.html#ga92ad3d4575d004d051798ca49b0a01dc", null ],
    [ "NT_GetValueType", "group__ntcore__typedgetters__cfunc.html#ga3686f29f4aebaecb5e276fbfe2b95954", null ]
];