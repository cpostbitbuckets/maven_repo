var struct_n_t___value =
[
    [ "arr", "struct_n_t___value.html#aec85a7da81866a1e38efcdcfa33249f7", null ],
    [ "arr", "struct_n_t___value.html#a585c8bbb8b307eaf70d47e91285b60e8", null ],
    [ "arr", "struct_n_t___value.html#a478ad5dcb928252836bfea3489751991", null ],
    [ "arr_boolean", "struct_n_t___value.html#af0b628733359b9047d568729a131e0b6", null ],
    [ "arr_double", "struct_n_t___value.html#a5b56031c9541313f7ff9aecc702860cd", null ],
    [ "arr_string", "struct_n_t___value.html#a811ab272d2dbd56f265f410d2ba9629a", null ],
    [ "data", "struct_n_t___value.html#aacab9f02bf5476774cb056f0592f3bee", null ],
    [ "last_change", "struct_n_t___value.html#abf83749e6dcf2eda3867a904e8ac8c80", null ],
    [ "size", "struct_n_t___value.html#ae8a4e621562c50054b6759e43323dc7f", null ],
    [ "type", "struct_n_t___value.html#a068c2a61fb025e5502658f99a189c842", null ],
    [ "v_boolean", "struct_n_t___value.html#ad57d2f0aaa820d67e013218183b9a329", null ],
    [ "v_double", "struct_n_t___value.html#ab4fee8c0729e8886dac8bb6a2ba13854", null ],
    [ "v_raw", "struct_n_t___value.html#a71b27798d67c53e6635d7c38997e3d31", null ],
    [ "v_string", "struct_n_t___value.html#a640ba6c5b32013f1a5e09597e4b77470", null ]
];