var struct_h_a_l___joystick_buttons =
[
    [ "buttons", "struct_h_a_l___joystick_buttons.html#a38ec62e88472f4c7918af189d4043cd4", null ],
    [ "count", "struct_h_a_l___joystick_buttons.html#ad2aeabb6cc9c523c765132c1749e82fd", null ]
];