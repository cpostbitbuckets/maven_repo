var structuv__timeval__t =
[
    [ "tv_sec", "structuv__timeval__t.html#a1d59b517f54431c86af88f55bbcec2b3", null ],
    [ "tv_usec", "structuv__timeval__t.html#a01e91a67c093b4393a343944766bc2d9", null ]
];