var group__ntcore__valuesetters__cfunc =
[
    [ "NT_SetEntryBoolean", "group__ntcore__valuesetters__cfunc.html#ga4241b3336dd976d05d3b679efd68f213", null ],
    [ "NT_SetEntryBooleanArray", "group__ntcore__valuesetters__cfunc.html#ga6b4b5303883bf3d784fc7aa8922ab8ad", null ],
    [ "NT_SetEntryDouble", "group__ntcore__valuesetters__cfunc.html#ga8e17f345bf4191a95ffde5ab0fe390b8", null ],
    [ "NT_SetEntryDoubleArray", "group__ntcore__valuesetters__cfunc.html#gac109161385214de3f427e3ad427e787a", null ],
    [ "NT_SetEntryRaw", "group__ntcore__valuesetters__cfunc.html#gaca3ee0f53839ddb17491e1cc3cd1807f", null ],
    [ "NT_SetEntryString", "group__ntcore__valuesetters__cfunc.html#ga0cb0f1870887cbab71cd712fe0b2f22a", null ],
    [ "NT_SetEntryStringArray", "group__ntcore__valuesetters__cfunc.html#ga8755e7e7edfb2ee133766b437d12f7fb", null ]
];