var group__cscore__utility__cfunc =
[
    [ "CS_UsbCameraInfo", "struct_c_s___usb_camera_info.html", [
      [ "dev", "struct_c_s___usb_camera_info.html#a81311211a5ded68cf47ac7cb02c5cbcf", null ],
      [ "name", "struct_c_s___usb_camera_info.html#aeaf92af97323e8e9382d48b72abc5a16", null ],
      [ "path", "struct_c_s___usb_camera_info.html#af8e259e0d7a97fc2f358458928aea8c5", null ]
    ] ],
    [ "CS_UsbCameraInfo", "group__cscore__utility__cfunc.html#ga06268de9df5860347f01e444c58631d9", null ]
];