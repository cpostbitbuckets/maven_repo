var group__ntcore__setdefault__cfunc =
[
    [ "NT_SetDefaultEntryBoolean", "group__ntcore__setdefault__cfunc.html#ga4d5af0daf5ffbc6866929dd5a6f4a572", null ],
    [ "NT_SetDefaultEntryBooleanArray", "group__ntcore__setdefault__cfunc.html#gab8c94073294e42f18de8504642e0f2d9", null ],
    [ "NT_SetDefaultEntryDouble", "group__ntcore__setdefault__cfunc.html#gaf7f6e4e0605a280b9408039fcc9d31fa", null ],
    [ "NT_SetDefaultEntryDoubleArray", "group__ntcore__setdefault__cfunc.html#ga4178d36c33edc72f8fb34d9035c7ccb8", null ],
    [ "NT_SetDefaultEntryRaw", "group__ntcore__setdefault__cfunc.html#ga263ed0ded4943913b0e1f6a33f09123f", null ],
    [ "NT_SetDefaultEntryString", "group__ntcore__setdefault__cfunc.html#ga549a3cd4b6a70946e7c50b22347129b9", null ],
    [ "NT_SetDefaultEntryStringArray", "group__ntcore__setdefault__cfunc.html#gaadcd435edea069ea9f25509435324288", null ]
];