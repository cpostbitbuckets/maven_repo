var classcs_1_1_video_property =
[
    [ "Kind", "group__cscore__oo.html#ga7c48bc795a9e2e6a9e2b22ec543c50c1", [
      [ "kNone", "group__cscore__oo.html#gga7c48bc795a9e2e6a9e2b22ec543c50c1aa9ec4c3664d4dfbdb20af1a3ddc7c6fa", null ],
      [ "kBoolean", "group__cscore__oo.html#gga7c48bc795a9e2e6a9e2b22ec543c50c1a3d78268e24ac5ace2c369140cd338f0d", null ],
      [ "kInteger", "group__cscore__oo.html#gga7c48bc795a9e2e6a9e2b22ec543c50c1a310a54ab27fd355ef62640ccff9d2ab7", null ],
      [ "kString", "group__cscore__oo.html#gga7c48bc795a9e2e6a9e2b22ec543c50c1a167dbac057b380e54ea7f3c2f7414e07", null ],
      [ "kEnum", "group__cscore__oo.html#gga7c48bc795a9e2e6a9e2b22ec543c50c1a318d3bf8a63b515c034888085b03bdeb", null ]
    ] ],
    [ "VideoProperty", "classcs_1_1_video_property.html#aebc0147a974d855e85931fb4677bb8d2", null ],
    [ "Get", "classcs_1_1_video_property.html#a2298952b56a157786b074ef7dc3c420f", null ],
    [ "GetChoices", "classcs_1_1_video_property.html#ab2854b99396098c5523cf9e74d5c4717", null ],
    [ "GetDefault", "classcs_1_1_video_property.html#aab3ea57bc09409fa652e2b62b013ca9f", null ],
    [ "GetKind", "classcs_1_1_video_property.html#abad18527829c76d44d8d09ccda993c56", null ],
    [ "GetLastStatus", "classcs_1_1_video_property.html#aba33d2cb63edc06f807fb73fa0ec8fc2", null ],
    [ "GetMax", "classcs_1_1_video_property.html#a42404455cb3de47ca5d67165f1dfc2ce", null ],
    [ "GetMin", "classcs_1_1_video_property.html#a158de85607b2639a4c2d4a7bb401f2ca", null ],
    [ "GetName", "classcs_1_1_video_property.html#a5b4a2aafc538890fbcf7db5eb8675f76", null ],
    [ "GetStep", "classcs_1_1_video_property.html#abc013140a02551839875aaf25676c7be", null ],
    [ "GetString", "classcs_1_1_video_property.html#a740411de1740dc82732f4ad5bf57dbcb", null ],
    [ "GetString", "classcs_1_1_video_property.html#afac8aa9df1d21c02e621830c33293bd6", null ],
    [ "IsBoolean", "classcs_1_1_video_property.html#a13e910116e63e8535c43a576d8114ca8", null ],
    [ "IsEnum", "classcs_1_1_video_property.html#a63fa896593e4ba7d3c867d56bd71abb1", null ],
    [ "IsInteger", "classcs_1_1_video_property.html#ab168353335617819a76a3ccbdc90c765", null ],
    [ "IsString", "classcs_1_1_video_property.html#abaeea8fc8743dff65551d67951fdac5f", null ],
    [ "operator bool", "classcs_1_1_video_property.html#af8cae44df8ab7616778e7fc5f60fba8d", null ],
    [ "Set", "classcs_1_1_video_property.html#aa04937e7ca5df1740b49e938334521de", null ],
    [ "SetString", "classcs_1_1_video_property.html#aa880d95de0c837819cfb58231826147e", null ],
    [ "CvSource", "classcs_1_1_video_property.html#ad378ad5d66e5445bc33358aa187081c7", null ],
    [ "VideoEvent", "classcs_1_1_video_property.html#ace63f20158a3037e0316962613f821f2", null ],
    [ "VideoSink", "classcs_1_1_video_property.html#a761a1a07505f1d3f9776b46815d4ef0d", null ],
    [ "VideoSource", "classcs_1_1_video_property.html#ad165dabf73053c60bb1c4386ea0a3387", null ]
];