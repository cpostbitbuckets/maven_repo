var classcs_1_1_cv_sink =
[
    [ "CvSink", "classcs_1_1_cv_sink.html#a167b539d704a86b13accd2fc4d971fa7", null ],
    [ "CvSink", "classcs_1_1_cv_sink.html#a22c6a90d9afe6563b479df9913eda028", null ],
    [ "CvSink", "classcs_1_1_cv_sink.html#a304f88807149dcf9d18ca1fc7d6dec29", null ],
    [ "GetError", "classcs_1_1_cv_sink.html#a7f05619a7db6d383f0228b503d3f3c59", null ],
    [ "GrabFrame", "classcs_1_1_cv_sink.html#a6d0124766c65fa0bd544b2d1648e7cf9", null ],
    [ "GrabFrameNoTimeout", "classcs_1_1_cv_sink.html#a6a66f34b4ef61e456e6cccdbe6181487", null ],
    [ "SetDescription", "classcs_1_1_cv_sink.html#af243cb165a1f22ed74f1bfae3ee7904c", null ],
    [ "SetEnabled", "classcs_1_1_cv_sink.html#a06e368261e8190c335076fcc9df39959", null ]
];