var classcs_1_1_video_camera =
[
    [ "WhiteBalance", "group__cscore__oo.html#gae69e023351826887120c793b4e878d25", [
      [ "kFixedIndoor", "group__cscore__oo.html#ggae69e023351826887120c793b4e878d25a43ba7c70cb6ecb25ff9f233919d12438", null ],
      [ "kFixedOutdoor1", "group__cscore__oo.html#ggae69e023351826887120c793b4e878d25a02d7962ea716ff8d107cfb004b3a43d6", null ],
      [ "kFixedOutdoor2", "group__cscore__oo.html#ggae69e023351826887120c793b4e878d25afd69b1ea0b69d58ef102de98fe0e5ba0", null ],
      [ "kFixedFluorescent1", "group__cscore__oo.html#ggae69e023351826887120c793b4e878d25aea7ffda53418a14b0fb0642c7b3272ab", null ],
      [ "kFixedFlourescent2", "group__cscore__oo.html#ggae69e023351826887120c793b4e878d25a41082db3698a95ff83046467900bcb01", null ]
    ] ],
    [ "VideoCamera", "classcs_1_1_video_camera.html#adaa26f5f88023688b31453df12c44511", null ],
    [ "VideoCamera", "classcs_1_1_video_camera.html#a26e94555de3a53001190c120da2235f9", null ],
    [ "GetBrightness", "classcs_1_1_video_camera.html#a9ae04e17f8d19d12b7186b1bd40c4b86", null ],
    [ "SetBrightness", "classcs_1_1_video_camera.html#ac1e730756361d382f4b2cacbcd9d55af", null ],
    [ "SetExposureAuto", "classcs_1_1_video_camera.html#a5a7a683e022b3e9023f851f58884e00d", null ],
    [ "SetExposureHoldCurrent", "classcs_1_1_video_camera.html#afa2914d97d62a5efcdf47ef365fabf8b", null ],
    [ "SetExposureManual", "classcs_1_1_video_camera.html#ae20cf9ed652f3002e3d8bbde3780467b", null ],
    [ "SetWhiteBalanceAuto", "classcs_1_1_video_camera.html#a6e1b5e8232e9b893cb90ded5813600d6", null ],
    [ "SetWhiteBalanceHoldCurrent", "classcs_1_1_video_camera.html#ad23d645013813023e3f44bd74181c730", null ],
    [ "SetWhiteBalanceManual", "classcs_1_1_video_camera.html#a5aac3d58106609080305cad5dd7c7c1e", null ]
];