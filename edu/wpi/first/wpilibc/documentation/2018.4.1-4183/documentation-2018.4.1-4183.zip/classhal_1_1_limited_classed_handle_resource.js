var classhal_1_1_limited_classed_handle_resource =
[
    [ "LimitedClassedHandleResource", "classhal_1_1_limited_classed_handle_resource.html#a9a8a4d23cb0d927ae0ea89edcb62187f", null ],
    [ "LimitedClassedHandleResource", "classhal_1_1_limited_classed_handle_resource.html#a8db2ef67552b00e330ed4a7eba2b9a64", null ],
    [ "Allocate", "classhal_1_1_limited_classed_handle_resource.html#a2789ff3b3c53594e7d7314357b50f03b", null ],
    [ "Free", "classhal_1_1_limited_classed_handle_resource.html#a9a5f1b0de6c49d510086353448c17eed", null ],
    [ "Get", "classhal_1_1_limited_classed_handle_resource.html#aa7ab524f83d6fc57621c9135b057a681", null ],
    [ "operator=", "classhal_1_1_limited_classed_handle_resource.html#ab000c6478751b5a75b081d6fa8059ef6", null ],
    [ "ResetHandles", "classhal_1_1_limited_classed_handle_resource.html#a1b3266ef173f794eb3a724e6c67f7f94", null ],
    [ "LimitedClassedHandleResourceTest", "classhal_1_1_limited_classed_handle_resource.html#ab7edf9292a3c19eb6cd76eb6454d1a7d", null ]
];