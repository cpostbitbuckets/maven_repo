var structwpi_1_1detail_1_1fwd__or__bidi__tag__impl =
[
    [ "type", "structwpi_1_1detail_1_1fwd__or__bidi__tag__impl.html#ad00687c4530026b4abcf195bd0df589c", null ]
];