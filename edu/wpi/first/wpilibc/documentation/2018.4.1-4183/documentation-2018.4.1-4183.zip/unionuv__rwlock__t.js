var unionuv__rwlock__t =
[
    [ "num_readers_", "unionuv__rwlock__t.html#a00d48767aa37f395d8cd862916cd2508", null ],
    [ "num_readers_lock_", "unionuv__rwlock__t.html#a19279f1288ef8a749054e2da9024bad0", null ],
    [ "state_", "unionuv__rwlock__t.html#ae0dbccbc0905d0c54952e589ce79ce58", null ],
    [ "unused1_", "unionuv__rwlock__t.html#a26d8fda28b2c4841646bced8169d4c03", null ],
    [ "unused1_", "unionuv__rwlock__t.html#ae4a7b0c92c19739a2be67d2093890e62", null ],
    [ "unused2_", "unionuv__rwlock__t.html#a7ab7e63121821a45064dce095e075286", null ],
    [ "unused2_", "unionuv__rwlock__t.html#a02a59903e6cc847d7d7589333138b962", null ],
    [ "unused_", "unionuv__rwlock__t.html#ab930a64984592b65ea6e361723d4bffd", null ],
    [ "write_semaphore_", "unionuv__rwlock__t.html#a30c290365076330dcb1743bc08334310", null ]
];