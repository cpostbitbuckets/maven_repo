var classwpi_1_1_debug_epoch_base =
[
    [ "HandleBase", "classwpi_1_1_debug_epoch_base_1_1_handle_base.html", "classwpi_1_1_debug_epoch_base_1_1_handle_base" ],
    [ "DebugEpochBase", "classwpi_1_1_debug_epoch_base.html#a56c7baf9700920d0c6243b5dea37eb1e", null ],
    [ "~DebugEpochBase", "classwpi_1_1_debug_epoch_base.html#a54237a8793e15f16f377a6a0333abcad", null ],
    [ "incrementEpoch", "classwpi_1_1_debug_epoch_base.html#a152a9f2839bd8c3b275520902cdf8944", null ]
];