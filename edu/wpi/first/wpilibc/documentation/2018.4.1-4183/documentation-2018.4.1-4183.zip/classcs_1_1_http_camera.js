var classcs_1_1_http_camera =
[
    [ "HttpCameraKind", "group__cscore__oo.html#ga83a6f6ff2f5c00b49faf6488aab9321d", [
      [ "kUnknown", "group__cscore__oo.html#gga83a6f6ff2f5c00b49faf6488aab9321dad046dd82c51480b98656cf5077835de1", null ],
      [ "kMJPGStreamer", "group__cscore__oo.html#gga83a6f6ff2f5c00b49faf6488aab9321da21eac708647501c1961d597898838582", null ],
      [ "kCSCore", "group__cscore__oo.html#gga83a6f6ff2f5c00b49faf6488aab9321dabfc70e68ff7f22d8fca0ab3e6e020f4e", null ],
      [ "kAxis", "group__cscore__oo.html#gga83a6f6ff2f5c00b49faf6488aab9321dacff84bf2f22913f78ea13b4c2079ff92", null ]
    ] ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#a45c0dcc17442aef0bb0dfde06dea870b", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#ae6b960450f072ed81134081faaf6b1aa", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#ad9f3316e59ef5b107934a92b426160a6", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#ad1353ac1dd367a2cb4ec4734501657c9", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#a9b8a43ab418634f6f1fb965aa7be8e95", null ],
    [ "GetHttpCameraKind", "classcs_1_1_http_camera.html#a6442a709f2deb3f7b8be8075172c66ac", null ],
    [ "GetUrls", "classcs_1_1_http_camera.html#aaa123a1795bfa3155c4f5abd4a4b85ed", null ],
    [ "SetUrls", "classcs_1_1_http_camera.html#ab762fd8fd190f92155c52f95e37558ba", null ],
    [ "SetUrls", "classcs_1_1_http_camera.html#a4b048a5e03c69c86836b8aba70eba501", null ]
];