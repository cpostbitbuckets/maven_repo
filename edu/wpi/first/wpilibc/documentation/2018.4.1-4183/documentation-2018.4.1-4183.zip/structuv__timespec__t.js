var structuv__timespec__t =
[
    [ "tv_nsec", "structuv__timespec__t.html#af1552c618f27286c9734be801d0ecf3f", null ],
    [ "tv_sec", "structuv__timespec__t.html#a6c1e6a2cd2d9f10dc4df27ab3a79bc9d", null ]
];