var struct_n_t___entry_notification =
[
    [ "entry", "struct_n_t___entry_notification.html#af1127cfc472c444761c27723e4df8389", null ],
    [ "flags", "struct_n_t___entry_notification.html#ac22a071e4cb9648cdd894dfda1ade6ff", null ],
    [ "listener", "struct_n_t___entry_notification.html#a341a36e7e9d796a8417df94ff8c4fe4c", null ],
    [ "name", "struct_n_t___entry_notification.html#adf53363e9c6c9be99f6b59608721f0bd", null ],
    [ "value", "struct_n_t___entry_notification.html#a443b7dae05f8d597197954d5df8e95d0", null ]
];