var structuv____io__s =
[
    [ "cb", "structuv____io__s.html#a155c800db22abfac6c65e717ea5e17cc", null ],
    [ "events", "structuv____io__s.html#a575481d9c01f83f1fd15e3f0a2a8befc", null ],
    [ "fd", "structuv____io__s.html#ad54f5c79beefb3c45d5053968c05950e", null ],
    [ "pending_queue", "structuv____io__s.html#a9fd9e9bc633f4a68988d4d11934d834e", null ],
    [ "pevents", "structuv____io__s.html#a9a8ba3ae3e18355c3341e2e50657c73a", null ],
    [ "watcher_queue", "structuv____io__s.html#a28f768761c5a496256263f7677f4be9c", null ]
];