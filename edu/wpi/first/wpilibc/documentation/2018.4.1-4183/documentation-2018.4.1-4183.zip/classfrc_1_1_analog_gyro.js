var classfrc_1_1_analog_gyro =
[
    [ "AnalogGyro", "classfrc_1_1_analog_gyro.html#a4a6cd791f9cdcefaeccf900b5db0a77d", null ],
    [ "AnalogGyro", "classfrc_1_1_analog_gyro.html#a312dc00ee38cc067025fd26b0d1aece0", null ],
    [ "AnalogGyro", "classfrc_1_1_analog_gyro.html#a443576cfaed61b10f424eb64079ed395", null ],
    [ "AnalogGyro", "classfrc_1_1_analog_gyro.html#a914a753fd3f376cdefeee86ad6f74aaf", null ],
    [ "AnalogGyro", "classfrc_1_1_analog_gyro.html#a438ae8c9fa43e614de079eddf1a93b90", null ],
    [ "~AnalogGyro", "classfrc_1_1_analog_gyro.html#afcebca0cc77d16fe174ec9feda182bca", null ],
    [ "AnalogGyro", "classfrc_1_1_analog_gyro.html#a72eeb926ded094778e68d4c627a61fe6", null ],
    [ "Calibrate", "classfrc_1_1_analog_gyro.html#a3ba83f65e119cfc1aef97509cfd66a75", null ],
    [ "GetAngle", "classfrc_1_1_analog_gyro.html#aa38b3651e2e5e3dd6c564ba5f90f869b", null ],
    [ "GetCenter", "classfrc_1_1_analog_gyro.html#a0aaa40e2ec91182eb1398f87d2d4075a", null ],
    [ "GetOffset", "classfrc_1_1_analog_gyro.html#ab44f3c240a2871a23d8fc77837a77c33", null ],
    [ "GetRate", "classfrc_1_1_analog_gyro.html#ac4b9f9b77003b05b4445ea0468aa414d", null ],
    [ "InitGyro", "classfrc_1_1_analog_gyro.html#aa12e67bc38a907989942a24bd63703b7", null ],
    [ "operator=", "classfrc_1_1_analog_gyro.html#a133cc371cff2d63e6978258b2cb165c3", null ],
    [ "Reset", "classfrc_1_1_analog_gyro.html#accdcfbda4482f484ae40e2670051cd28", null ],
    [ "SetDeadband", "classfrc_1_1_analog_gyro.html#a0a99f91859b549a7166723640fe251ca", null ],
    [ "SetSensitivity", "classfrc_1_1_analog_gyro.html#ad159eb656c8dde6546dc3014ba3372bc", null ],
    [ "m_analog", "classfrc_1_1_analog_gyro.html#ad9cbc2ae26bf1971028a84fef6997a01", null ]
];