var structuv__once__s =
[
    [ "event", "structuv__once__s.html#a2bf4247a8c9fe869796f2fb6afd76eb4", null ],
    [ "ran", "structuv__once__s.html#a95803dd202dab4cb7b1578d09f79f2f8", null ]
];