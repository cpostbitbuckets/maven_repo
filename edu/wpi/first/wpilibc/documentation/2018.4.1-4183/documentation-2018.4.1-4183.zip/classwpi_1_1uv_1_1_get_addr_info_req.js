var classwpi_1_1uv_1_1_get_addr_info_req =
[
    [ "GetAddrInfoReq", "classwpi_1_1uv_1_1_get_addr_info_req.html#a2de869d824de963ae642697141bc9f79", null ],
    [ "GetLoop", "classwpi_1_1uv_1_1_get_addr_info_req.html#a0eabad7064c4bcb8a85a2f9314dd3c60", null ],
    [ "resolved", "classwpi_1_1uv_1_1_get_addr_info_req.html#a64960214931e8f3297f01fbe2190fe07", null ]
];