var classwpi_1_1_reference_storage =
[
    [ "ReferenceStorage", "classwpi_1_1_reference_storage.html#a78bce240c9ed1872d079048a77424ece", null ],
    [ "get", "classwpi_1_1_reference_storage.html#adc1009d80e0044c67b987c30397b3a6b", null ],
    [ "operator T &", "classwpi_1_1_reference_storage.html#aeaed2d60040b57f5f5ac4e7cd0361b42", null ]
];