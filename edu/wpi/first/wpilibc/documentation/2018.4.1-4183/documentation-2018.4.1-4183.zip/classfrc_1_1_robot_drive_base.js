var classfrc_1_1_robot_drive_base =
[
    [ "MotorType", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754", [
      [ "kFrontLeft", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754a10b4c2722341a2b7e41ddfd45c019cdc", null ],
      [ "kFrontRight", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754a5f2fc6a85d38b20ae27e441ece6fbc6b", null ],
      [ "kRearLeft", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754a7eef0180865cff6233c8c521c808f96c", null ],
      [ "kRearRight", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754a6a850db63077ec5fe5b0445e783664e8", null ],
      [ "kLeft", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754a024977796e74c04a6f0cdd027580a0e9", null ],
      [ "kRight", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754a2e9ff3c98bdf920a7cb9314b38beb007", null ],
      [ "kBack", "classfrc_1_1_robot_drive_base.html#a91bbe6376ee340272ae36ea20b608754aef2d7e716b69e79e5d4843838a5c5e79", null ]
    ] ],
    [ "RobotDriveBase", "classfrc_1_1_robot_drive_base.html#ad796a29767020626aa35b2a42fba8264", null ],
    [ "~RobotDriveBase", "classfrc_1_1_robot_drive_base.html#a821b770d27682489c54eeb76b52aad00", null ],
    [ "RobotDriveBase", "classfrc_1_1_robot_drive_base.html#ae011f3027be53e5d24b38ea976139c56", null ],
    [ "ApplyDeadband", "classfrc_1_1_robot_drive_base.html#a3133ccfbbc5fe81830d88f8eed6c6b6a", null ],
    [ "FeedWatchdog", "classfrc_1_1_robot_drive_base.html#ac407bc60830a0d639de96bdc53d58a0f", null ],
    [ "GetDescription", "classfrc_1_1_robot_drive_base.html#a9dc728746014c7dc2b7141dac93a2b23", null ],
    [ "GetExpiration", "classfrc_1_1_robot_drive_base.html#a3f9e1687d4a9ed45dbd6516a177ea0e2", null ],
    [ "IsAlive", "classfrc_1_1_robot_drive_base.html#ac50b72dc262b67b544f88f2205919253", null ],
    [ "IsSafetyEnabled", "classfrc_1_1_robot_drive_base.html#a607d4406763af2ff6317ed9f544969d6", null ],
    [ "Limit", "classfrc_1_1_robot_drive_base.html#afca1832d4ddcef37e6d73ecba58f59c6", null ],
    [ "Normalize", "classfrc_1_1_robot_drive_base.html#aa45f7b95febc8a46c959d1aef2613467", null ],
    [ "operator=", "classfrc_1_1_robot_drive_base.html#a45bfa04aeb304c0bea2e000f428933fc", null ],
    [ "SetDeadband", "classfrc_1_1_robot_drive_base.html#a66ca9d336c81659405045bf064490cfe", null ],
    [ "SetExpiration", "classfrc_1_1_robot_drive_base.html#ae9bf934e8a166b4081317415ddf16882", null ],
    [ "SetMaxOutput", "classfrc_1_1_robot_drive_base.html#aa4970502fd5575de5602213c092c5aaf", null ],
    [ "SetSafetyEnabled", "classfrc_1_1_robot_drive_base.html#a330099666d99d4566164cffc78c7efbc", null ],
    [ "StopMotor", "classfrc_1_1_robot_drive_base.html#a463d317b667cef70681fb58ab5a27662", null ],
    [ "m_deadband", "classfrc_1_1_robot_drive_base.html#a750d348d0107fcdcfcd41318101b4194", null ],
    [ "m_maxOutput", "classfrc_1_1_robot_drive_base.html#afd5629481f44e20bcf2c79efba271ecb", null ],
    [ "m_safetyHelper", "classfrc_1_1_robot_drive_base.html#ab094c780554b3f2149fde51d5b4118fe", null ]
];