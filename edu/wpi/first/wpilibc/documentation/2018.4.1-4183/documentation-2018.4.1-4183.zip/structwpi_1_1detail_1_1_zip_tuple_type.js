var structwpi_1_1detail_1_1_zip_tuple_type =
[
    [ "type", "structwpi_1_1detail_1_1_zip_tuple_type.html#aa672bf00c2948c8caace1a1540d122fd", null ]
];