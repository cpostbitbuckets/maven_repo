var classcs_1_1_video_sink =
[
    [ "Kind", "group__cscore__oo.html#ga2dfd389f1cdd5173d67b7dc235c2aba0", [
      [ "kUnknown", "group__cscore__oo.html#gga2dfd389f1cdd5173d67b7dc235c2aba0a5d19dd4bf3e13fa32a251cce3b6fdb09", null ],
      [ "kMjpeg", "group__cscore__oo.html#gga2dfd389f1cdd5173d67b7dc235c2aba0abcfa425d0b0ee0c1ffa5f7bc1fadc914", null ],
      [ "kCv", "group__cscore__oo.html#gga2dfd389f1cdd5173d67b7dc235c2aba0a11620df819b547b946fdd567140eff73", null ]
    ] ],
    [ "VideoSink", "classcs_1_1_video_sink.html#adb35ad41cf1ec445fb85151a52880442", null ],
    [ "VideoSink", "classcs_1_1_video_sink.html#a3417fb32f5991c9a10ba9a260355ffd7", null ],
    [ "VideoSink", "classcs_1_1_video_sink.html#a8340d91219b5314f541d3fbe1fd6fbad", null ],
    [ "~VideoSink", "classcs_1_1_video_sink.html#af66f12a6193e13b432e3fa09ae784a0a", null ],
    [ "VideoSink", "classcs_1_1_video_sink.html#ae26824710e91ad43e657799141e3b820", null ],
    [ "EnumerateProperties", "classcs_1_1_video_sink.html#a789acfd477d3c6b099e85885b4f16f4d", null ],
    [ "GetDescription", "classcs_1_1_video_sink.html#a839dc9eadc07ca0ce4214bba4e1f61f7", null ],
    [ "GetHandle", "classcs_1_1_video_sink.html#a38e9542fbe008d5a4883815014f6dbe4", null ],
    [ "GetKind", "classcs_1_1_video_sink.html#ade640b4951de6bde45a5003d2c586295", null ],
    [ "GetLastStatus", "classcs_1_1_video_sink.html#a9fb479006c32c4a8c575a67688f28c7a", null ],
    [ "GetName", "classcs_1_1_video_sink.html#aa79cb5faa86abf3b2ae819cda7c2baf3", null ],
    [ "GetProperty", "classcs_1_1_video_sink.html#a74db71a33f3789bbf639faa666c10501", null ],
    [ "GetSource", "classcs_1_1_video_sink.html#a9b54d3e29dca74af7c10ec4b8a3e4ccb", null ],
    [ "GetSourceProperty", "classcs_1_1_video_sink.html#a123e18b3ae17428510a318c8566ea493", null ],
    [ "operator bool", "classcs_1_1_video_sink.html#a1ea091781e94b5a06a93720ee8eb36e1", null ],
    [ "operator!=", "classcs_1_1_video_sink.html#a2123f5e69dae4ff5747c6b62917d7346", null ],
    [ "operator=", "classcs_1_1_video_sink.html#aa6c5e370fc420b2ef92effe1359089cc", null ],
    [ "operator==", "classcs_1_1_video_sink.html#a67c1ee9abd5e73ea05b4186a4f0be896", null ],
    [ "SetSource", "classcs_1_1_video_sink.html#a2b70769fba97197eb54e05c01ef3f1f3", null ],
    [ "swap", "classcs_1_1_video_sink.html#a3b09ad5ebf2b5e5d2f9733ed3a24191f", null ],
    [ "VideoEvent", "classcs_1_1_video_sink.html#ace63f20158a3037e0316962613f821f2", null ],
    [ "VideoSource", "classcs_1_1_video_sink.html#ad165dabf73053c60bb1c4386ea0a3387", null ],
    [ "m_handle", "classcs_1_1_video_sink.html#acfec435f0b19e839c0985475afd909a9", null ],
    [ "m_status", "classcs_1_1_video_sink.html#aa8ac685c994e9c56738b029ca5392d38", null ]
];