var structuv__lib__t =
[
    [ "errmsg", "structuv__lib__t.html#a098655badc5308af959cdac4c2809340", null ],
    [ "handle", "structuv__lib__t.html#a324a35f16aeed41ee8f1ce1604998206", null ],
    [ "handle", "structuv__lib__t.html#ac9404effab57460e2bd51b054d31aede", null ]
];