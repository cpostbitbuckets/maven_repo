var classfrc_1_1_motor_safety =
[
    [ "MotorSafety", "classfrc_1_1_motor_safety.html#a1b58af6c3ddfef295286f0449316b025", null ],
    [ "MotorSafety", "classfrc_1_1_motor_safety.html#a4e4539a4bff3d8d6ba40588768236dca", null ],
    [ "GetDescription", "classfrc_1_1_motor_safety.html#ac92187de068783dab3a6325bcdf22542", null ],
    [ "GetExpiration", "classfrc_1_1_motor_safety.html#a47d1ac9a080eb729d0d1ad4330b2a799", null ],
    [ "IsAlive", "classfrc_1_1_motor_safety.html#a3ecb4db9baf7f728ea2850e9ecd6d9f0", null ],
    [ "IsSafetyEnabled", "classfrc_1_1_motor_safety.html#a57deb13a68b44026168bdf8728043ce3", null ],
    [ "operator=", "classfrc_1_1_motor_safety.html#a57277d4248350896287ea08ec43ed5b9", null ],
    [ "SetExpiration", "classfrc_1_1_motor_safety.html#a7d3706b0fadff9d8e4a081d3bb3b6b9f", null ],
    [ "SetSafetyEnabled", "classfrc_1_1_motor_safety.html#ac59cf64d4c10948d6cc9cdd33418a27b", null ],
    [ "StopMotor", "classfrc_1_1_motor_safety.html#a0269b4f422dd90c886074a41a5f7400a", null ]
];