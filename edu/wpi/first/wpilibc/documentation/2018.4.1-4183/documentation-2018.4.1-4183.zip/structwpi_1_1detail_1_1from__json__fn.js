var structwpi_1_1detail_1_1from__json__fn =
[
    [ "operator()", "structwpi_1_1detail_1_1from__json__fn.html#a673d7ef1eedd58739ca8e693e2424566", null ]
];