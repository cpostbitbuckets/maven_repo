var struct___a_f_d___p_o_l_l___i_n_f_o =
[
    [ "Exclusive", "struct___a_f_d___p_o_l_l___i_n_f_o.html#acc55cd6176cbd088afa107ec38573cc1", null ],
    [ "Handles", "struct___a_f_d___p_o_l_l___i_n_f_o.html#ae72b9c1736ba89ccfbcffda40588c67d", null ],
    [ "NumberOfHandles", "struct___a_f_d___p_o_l_l___i_n_f_o.html#ac37001d47d932e44224b70ffe7233d30", null ],
    [ "Timeout", "struct___a_f_d___p_o_l_l___i_n_f_o.html#a0504993706eef7ab023467030519adb9", null ]
];