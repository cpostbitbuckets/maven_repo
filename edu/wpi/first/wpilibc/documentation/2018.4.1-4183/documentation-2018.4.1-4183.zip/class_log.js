var class_log =
[
    [ "Log", "class_log.html#af6071a60aa52b6c1b511f99b4bc1b8fe", null ],
    [ "~Log", "class_log.html#a0fbfda88fbee5027c89f6eb121059360", null ],
    [ "Get", "class_log.html#a7ca7921330b4b72d9be6038548d7fabe", null ],
    [ "buf", "class_log.html#a4c911724ee6e604ca2d28bb5205f87f3", null ],
    [ "buf", "class_log.html#a588ede8dbd9f08a058661a8d14be17a3", null ]
];