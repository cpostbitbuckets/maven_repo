var struct_n_t___connection_notification =
[
    [ "conn", "struct_n_t___connection_notification.html#a46228561287d59ee9191f74270a58967", null ],
    [ "connected", "struct_n_t___connection_notification.html#a9f0adeeeb6e0d91b9f9231b8784bf0a0", null ],
    [ "listener", "struct_n_t___connection_notification.html#a94cc2f3b8a74683859f14f9d5a9c1ea1", null ]
];