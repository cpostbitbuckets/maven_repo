var classfrc_1_1_error_base =
[
    [ "ErrorBase", "classfrc_1_1_error_base.html#a5f7c61fe7ebebf98b0cb242ae2b56d86", null ],
    [ "~ErrorBase", "classfrc_1_1_error_base.html#aee672f5203e6d1eb898878078e6086f0", null ],
    [ "ErrorBase", "classfrc_1_1_error_base.html#a230e50b0499f3f7d85516acb5a90aef1", null ],
    [ "ClearError", "classfrc_1_1_error_base.html#af6ce92db319ac2b8d518b66ea974f078", null ],
    [ "CloneError", "classfrc_1_1_error_base.html#a1ccbb0a6b45ac33522aeacde6b5598d9", null ],
    [ "GetError", "classfrc_1_1_error_base.html#a806377f4c2605e9115a8ea532c0dd3c8", null ],
    [ "GetError", "classfrc_1_1_error_base.html#a021aeec14dddfd90e2013f050ab423c8", null ],
    [ "operator=", "classfrc_1_1_error_base.html#a2494bdf75abee14185ba553ef7088b0e", null ],
    [ "SetErrnoError", "classfrc_1_1_error_base.html#ae4812c13c3dc1a40f353b9ef3219281a", null ],
    [ "SetError", "classfrc_1_1_error_base.html#aaf085a3396acffdb56a49755fcb847c4", null ],
    [ "SetErrorRange", "classfrc_1_1_error_base.html#a9b218e02a25666cbf66a618bb3cb11ea", null ],
    [ "SetImaqError", "classfrc_1_1_error_base.html#ad95f7d6cb419552ce1cb08a91bcf9269", null ],
    [ "SetWPIError", "classfrc_1_1_error_base.html#a831ef87fc3d1357cc8df0a7f47d992f0", null ],
    [ "StatusIsFatal", "classfrc_1_1_error_base.html#ad440e5440a4414a7c6d03b06895baf51", null ],
    [ "m_error", "classfrc_1_1_error_base.html#a37ea09ba2389bcd5b0cb96e9feccaa6a", null ]
];