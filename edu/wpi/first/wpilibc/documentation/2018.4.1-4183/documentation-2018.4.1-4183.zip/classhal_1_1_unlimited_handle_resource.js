var classhal_1_1_unlimited_handle_resource =
[
    [ "UnlimitedHandleResource", "classhal_1_1_unlimited_handle_resource.html#a540e4163ee0de8c502a336717bf6ab46", null ],
    [ "UnlimitedHandleResource", "classhal_1_1_unlimited_handle_resource.html#af4adc2aca08df29663fa71b608012076", null ],
    [ "Allocate", "classhal_1_1_unlimited_handle_resource.html#a89efd5665486c9fe70b1f5bd5ef9e15e", null ],
    [ "ForEach", "classhal_1_1_unlimited_handle_resource.html#a1934d40465ff731862204746d122f2dc", null ],
    [ "Free", "classhal_1_1_unlimited_handle_resource.html#af1b65772ebbc096c1ef29e6028c4bb31", null ],
    [ "Get", "classhal_1_1_unlimited_handle_resource.html#ab77509f5d4516448a3f9f67b21a506a7", null ],
    [ "operator=", "classhal_1_1_unlimited_handle_resource.html#aa95f8359a6f051b8292af0c68a55d7da", null ],
    [ "ResetHandles", "classhal_1_1_unlimited_handle_resource.html#a838b43ecce29204518f73f463cd81612", null ],
    [ "UnlimitedHandleResourceTest", "classhal_1_1_unlimited_handle_resource.html#ad075a367cf95509d8c457afc4cc2800a", null ]
];