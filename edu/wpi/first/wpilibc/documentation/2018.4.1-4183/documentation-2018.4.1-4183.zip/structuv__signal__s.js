var structuv__signal__s =
[
    [ "signal_cb", "structuv__signal__s.html#abe06e2ec8944818bb2e7886a166468d8", null ],
    [ "signum", "structuv__signal__s.html#ab25f2d111730c7e98bbdc554d7840c3c", null ]
];