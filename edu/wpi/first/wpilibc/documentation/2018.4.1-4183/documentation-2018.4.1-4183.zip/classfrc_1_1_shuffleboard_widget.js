var classfrc_1_1_shuffleboard_widget =
[
    [ "ShuffleboardWidget", "classfrc_1_1_shuffleboard_widget.html#a8028c9bafb3754e6fd1e96ccade29722", null ],
    [ "WithWidget", "classfrc_1_1_shuffleboard_widget.html#a7e687a909c52c39e32d9e2b6cb42865b", null ]
];