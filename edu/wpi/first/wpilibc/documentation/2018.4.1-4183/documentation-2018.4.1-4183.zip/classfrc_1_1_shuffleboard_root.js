var classfrc_1_1_shuffleboard_root =
[
    [ "DisableActuatorWidgets", "classfrc_1_1_shuffleboard_root.html#a3b10d7dfe4f6d055d660a0532525ad8e", null ],
    [ "EnableActuatorWidgets", "classfrc_1_1_shuffleboard_root.html#ad0262f5b0965bfc2a735d9f5bd2bd98b", null ],
    [ "GetTab", "classfrc_1_1_shuffleboard_root.html#af7f673d31ebc9cd4b8c2ce2f164bcd43", null ],
    [ "Update", "classfrc_1_1_shuffleboard_root.html#a59c9b95f0dcb7f008a87f074e4650117", null ]
];