var struct_n_t___rpc_result_def =
[
    [ "name", "struct_n_t___rpc_result_def.html#a62336ded4b4ab687033d2a8cc20c3046", null ],
    [ "type", "struct_n_t___rpc_result_def.html#a00736f2d6b25a1de5e45eaa0331f62c4", null ]
];