var classfrc_1_1_safe_p_w_m =
[
    [ "SafePWM", "classfrc_1_1_safe_p_w_m.html#af789165b5ffa8837e69d7ba65ef56360", null ],
    [ "~SafePWM", "classfrc_1_1_safe_p_w_m.html#aa1b46de6e8525f96ed7e9e6449bb2e6b", null ],
    [ "SafePWM", "classfrc_1_1_safe_p_w_m.html#a8ff350fb37d390208ac65119a24123d5", null ],
    [ "GetDescription", "classfrc_1_1_safe_p_w_m.html#a68d4077d14de4ec289aca9ad0d101863", null ],
    [ "GetExpiration", "classfrc_1_1_safe_p_w_m.html#a8bcc40fb5628a239dda886d5bf5473c3", null ],
    [ "IsAlive", "classfrc_1_1_safe_p_w_m.html#a2664e32d4b4b0c920e7689f396e072b0", null ],
    [ "IsSafetyEnabled", "classfrc_1_1_safe_p_w_m.html#ab9b686fd77b1bec599c7bd2459bbb6d9", null ],
    [ "operator=", "classfrc_1_1_safe_p_w_m.html#aebd384bb8230d0a7253f9cdc22ad0752", null ],
    [ "SetExpiration", "classfrc_1_1_safe_p_w_m.html#ac19aa171513bf74d1d731a202a38310f", null ],
    [ "SetSafetyEnabled", "classfrc_1_1_safe_p_w_m.html#a0f5990c06b2f8233bc2cc453b788c2de", null ],
    [ "SetSpeed", "classfrc_1_1_safe_p_w_m.html#a8c6e0d7fb9e13973fcd4a8d3ae80beab", null ],
    [ "StopMotor", "classfrc_1_1_safe_p_w_m.html#a1adef557ed0dbf83533f44f6053418a1", null ]
];