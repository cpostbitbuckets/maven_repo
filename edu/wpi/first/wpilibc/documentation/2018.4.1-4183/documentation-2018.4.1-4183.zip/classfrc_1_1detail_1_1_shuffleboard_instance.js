var classfrc_1_1detail_1_1_shuffleboard_instance =
[
    [ "ShuffleboardInstance", "classfrc_1_1detail_1_1_shuffleboard_instance.html#a59d9292449993f97a2b6b2bf4cb7f394", null ],
    [ "~ShuffleboardInstance", "classfrc_1_1detail_1_1_shuffleboard_instance.html#af653ca3afa50f3f42a460776b0c122aa", null ],
    [ "DisableActuatorWidgets", "classfrc_1_1detail_1_1_shuffleboard_instance.html#a8610dbc014e1570a9910b4fff270a50f", null ],
    [ "EnableActuatorWidgets", "classfrc_1_1detail_1_1_shuffleboard_instance.html#a708e6d687c35272aec06c4e73cd31fb9", null ],
    [ "GetTab", "classfrc_1_1detail_1_1_shuffleboard_instance.html#a89c683d84992dab96a5f8ce84e70d238", null ],
    [ "Update", "classfrc_1_1detail_1_1_shuffleboard_instance.html#a1e335714024cdcc4f9905715d7fd6028", null ]
];