var structuv__dirent__s =
[
    [ "name", "structuv__dirent__s.html#aad1b480800ccab684153290755baa047", null ],
    [ "type", "structuv__dirent__s.html#aa54978584ef03a77b4c3027909da772a", null ]
];