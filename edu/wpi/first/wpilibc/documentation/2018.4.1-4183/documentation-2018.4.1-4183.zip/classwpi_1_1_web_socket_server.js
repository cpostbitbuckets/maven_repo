var classwpi_1_1_web_socket_server =
[
    [ "ServerOptions", "structwpi_1_1_web_socket_server_1_1_server_options.html", "structwpi_1_1_web_socket_server_1_1_server_options" ],
    [ "WebSocketServer", "classwpi_1_1_web_socket_server.html#a827e21898d10db425177312a6fce6efc", null ],
    [ "connected", "classwpi_1_1_web_socket_server.html#ae6531c46249548e0c95f82b8e7cdf5a1", null ]
];