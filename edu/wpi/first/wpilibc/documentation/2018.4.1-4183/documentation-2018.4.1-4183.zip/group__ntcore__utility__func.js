var group__ntcore__utility__func =
[
    [ "Now", "group__ntcore__utility__func.html#ga9e57c1308e76272f160b24b18b3ee254", null ]
];