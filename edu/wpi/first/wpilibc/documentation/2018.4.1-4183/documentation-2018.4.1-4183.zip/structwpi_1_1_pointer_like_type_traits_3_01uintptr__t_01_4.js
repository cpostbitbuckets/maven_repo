var structwpi_1_1_pointer_like_type_traits_3_01uintptr__t_01_4 =
[
    [ "NumLowBitsAvailable", "structwpi_1_1_pointer_like_type_traits_3_01uintptr__t_01_4.html#af3707bb0d9987292b5a266d3c5df0baba11ccd833a38dab183f6c0ccbd0179090", null ]
];